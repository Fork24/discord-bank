require("dotenv").config();
const required = ["DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID"];
for (const key of required) {
  if (!process.env[key] || process.env[key].startsWith("PUT_")) {
    throw new Error(`Missing ${key}. Copy .env.example to .env and fill it in.`);
  }
}
module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  adminRoleId: process.env.ADMIN_ROLE_ID || null,
  currency: process.env.CURRENCY_NAME || "Coin",
  startingBalance: Math.max(0, Number.parseInt(process.env.STARTING_BALANCE || "1000", 10)),
  dailyReward: Math.max(0, Number.parseInt(process.env.DAILY_REWARD || "250", 10)),
  dailyCooldownMs: Math.max(1, Number.parseInt(process.env.DAILY_COOLDOWN_HOURS || "24", 10)) * 3600000,
  workCooldownMs: Math.max(1, Number.parseInt(process.env.WORK_COOLDOWN_MINUTES || "10", 10)) * 60000,
  bankInterestRate: Math.min(0.1, Math.max(0, Number(process.env.BANK_INTEREST_RATE || "0.01"))),
  bankInterestCap: Math.max(0, Number.parseInt(process.env.BANK_INTEREST_CAP || "100000", 10)),
  propertyOfflineCapMs: Math.max(1, Number.parseInt(process.env.PROPERTY_OFFLINE_CAP_HOURS || "24", 10)) * 3600000
};
