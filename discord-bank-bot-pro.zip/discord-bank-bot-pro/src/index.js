const {Client,GatewayIntentBits,EmbedBuilder,Events}=require("discord.js");
const config=require("./config"), db=require("./database");
const client=new Client({intents:[GatewayIntentBits.Guilds]});
const fmt=n=>new Intl.NumberFormat("en-US").format(n), money=n=>`${fmt(n)} ${config.currency}`;
const embed=(title,description,color=0x2ecc71)=>new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).setTimestamp();
const fail=(i,m)=>i.reply({embeds:[embed("تعذر تنفيذ العملية",m,0xe74c3c)],ephemeral:true});
const adminAllowed=i=>config.adminRoleId ? i.member.roles?.cache?.has(config.adminRoleId)===true : i.memberPermissions?.has("ManageGuild")===true;
const ensure=id=>db.ensureAccount(id,config.startingBalance);
const props={
 flat:{label:"شقة استثمارية",price:1000000,income:50000,resale:700000},
 villa:{label:"فيلا",price:5000000,income:180000,resale:3500000},
 tower:{label:"برج تجاري",price:20000000,income:800000,resale:14000000}
};
const timeLeft=ms=>{const h=Math.floor(ms/3600000),m=Math.ceil(ms%3600000/60000);return `${h} ساعة و${m} دقيقة`;};
const errors={
 ACCOUNT_UNAVAILABLE:"الحساب غير متاح أو محظور.",NOT_ENOUGH_WALLET:"رصيد محفظتك غير كافٍ.",
 NOT_ENOUGH_BANK:"رصيد البنك غير كافٍ.",PROPERTY_OWNED:"أنت تملك هذا العقار بالفعل.",
 NO_PROPERTY:"لا تملك هذا العقار.",LOAN_EXISTS:"يجب سداد قرضك الحالي قبل طلب قرض جديد.",
 LOAN_LIMIT:"الحد الأقصى للقرض 5,000,000.",NO_LOAN:"ليس لديك قرض قائم."
};
client.once(Events.ClientReady,c=>{console.log(`تم تشغيل البنك: ${c.user.tag}`);c.user.setActivity("الاقتصاد والاستثمار | /property shop");});
client.on(Events.InteractionCreate,async i=>{
 if(!i.isChatInputCommand())return;
 try{
  const uid=i.user.id;ensure(uid);
  if(i.commandName==="balance"){
   const u=i.options.getUser("member")||i.user,a=ensure(u.id);
   if(a.banned)return fail(i,"هذا الحساب محظور.");
   return i.reply({embeds:[embed(`حساب ${u.username}`,`**المحفظة:** ${money(a.wallet)}\n**البنك:** ${money(a.bank)}\n**القرض المستحق:** ${money(a.loan_balance)}\n**الإجمالي:** ${money(a.wallet+a.bank)}`)]});
  }
  if(i.commandName==="daily"){
   const r=db.dailyTx(uid,config.dailyReward,config.dailyCooldownMs);
   if(!r.claimed)return fail(i,`استلمت مكافأتك بالفعل. عُد بعد ${timeLeft(r.remaining)}.`);
   return i.reply({embeds:[embed("المكافأة اليومية",`أضيف إلى محفظتك **${money(config.dailyReward)}** 🎁`)]});
  }
  if(i.commandName==="work"){
   const r=db.workTx(uid,500,2500,config.workCooldownMs);
   if(!r.worked)return fail(i,`لقد عملت مؤخراً. انتظر ${timeLeft(r.remaining)}.`);
   return i.reply({embeds:[embed("انتهى دوامك!",`حصلت على راتب **${money(r.amount)}** مقابل عملك. 💼`)]});
  }
  if(["deposit","withdraw"].includes(i.commandName)){
   const n=i.options.getInteger("amount");
   i.commandName==="deposit"?db.depositTx(uid,n):db.withdrawTx(uid,n);
   return i.reply({embeds:[embed("تمت العملية",`${i.commandName==="deposit"?"أودعت في البنك":"سحبت من البنك"} **${money(n)}**.`)]});
  }
  if(i.commandName==="transfer"){
   const u=i.options.getUser("member"),n=i.options.getInteger("amount");
   if(u.bot||u.id===uid)return fail(i,"اختر عضواً آخر غير البوت أو نفسك.");
   ensure(u.id);db.transferTx(uid,u.id,n);
   return i.reply({embeds:[embed("تم التحويل",`أرسلت **${money(n)}** إلى ${u}.`)]});
  }
  if(i.commandName==="interest"){
   const r=db.interestTx(uid,config.bankInterestRate,config.bankInterestCap,86400000);
   if(!r.paid)return fail(i,`يمكنك استلام الفائدة بعد ${timeLeft(r.remaining)}.`);
   return i.reply({embeds:[embed("فائدة البنك",`تمت إضافة **${money(r.amount)}** إلى حسابك البنكي. معدل الفائدة: ${(config.bankInterestRate*100).toFixed(2)}% يومياً.`)]});
  }
  if(i.commandName==="loan"){
   const sub=i.options.getSubcommand(),a=db.getAccount(uid);
   if(sub==="status")return i.reply({embeds:[embed("حالة القرض",a.loan_balance?`المبلغ المستحق: **${money(a.loan_balance)}**\nموعد السداد: <t:${Math.floor(a.loan_due/1000)}:R>`:"ليس لديك قرض قائم.")],ephemeral:true});
   if(sub==="take"){
    const r=db.takeLoanTx(uid,i.options.getInteger("amount"));
    return i.reply({embeds:[embed("تمت الموافقة على القرض",`استلمت **${money(r.amount)}**.\nإجمالي السداد بعد رسوم 10%: **${money(r.total)}**.\nموعد السداد: <t:${Math.floor(r.due/1000)}:R>`)]});
   }
   const r=db.repayLoanTx(uid,i.options.getInteger("amount"));
   return i.reply({embeds:[embed("سداد القرض",`تم سداد **${money(r.paid)}**.\nالمتبقي: **${money(r.left)}**.`)]});
  }
  if(i.commandName==="property"){
   const sub=i.options.getSubcommand();
   if(sub==="shop"){
    const desc=Object.entries(props).map(([k,p])=>`**${p.label}** (\`${k}\`)\nالسعر: ${money(p.price)} | الدخل: ${money(p.income)} / دقيقة`).join("\n\n");
    return i.reply({embeds:[embed("🏘️ سوق العقارات",desc,0x3498db)]});
   }
   if(sub==="mine"){
    const owned=db.properties(uid);
    return i.reply({embeds:[embed("عقاراتك",owned.length?owned.map(x=>`• ${props[x.property_key]?.label||x.property_key}`).join("\n"):"لا تملك أي عقار حالياً. استخدم `/property shop`.")]});
   }
   const key=i.options.getString("name"),p=props[key];
   if(sub==="buy"){db.buyPropertyTx(uid,key,p.price);return i.reply({embeds:[embed("تم شراء العقار",`أصبحت تملك **${p.label}**!\nدخل العقار: **${money(p.income)} لكل دقيقة**.\nاستخدم \`/property collect\` لتحصيل الأرباح.`)]});}
   if(sub==="collect"){
    const r=db.collectPropertyTx(uid,key,p.income,config.propertyOfflineCapMs);
    return i.reply({embeds:[embed("تحصيل دخل العقار",r.amount?`حصلت على **${money(r.amount)}** عن **${r.minutes} دقيقة**.`:`لا توجد أرباح مستحقة بعد. انتظر دقيقة واحدة على الأقل.`)]});
   }
   if(sub==="sell"){db.sellPropertyTx(uid,key,p.resale);return i.reply({embeds:[embed("تم بيع العقار",`بعت **${p.label}** واستلمت **${money(p.resale)}**.`)]});}
  }
  if(i.commandName==="leaderboard"){
   const rows=db.leaderboard.all(),desc=rows.length?rows.map((r,n)=>`**${n+1}.** <@${r.user_id}> — ${money(r.total)}`).join("\n"):"لا توجد حسابات بعد.";
   return i.reply({embeds:[embed("🏆 أغنى أعضاء السيرفر",desc,0xf1c40f)]});
  }
  if(i.commandName==="history"){
   const rows=db.history.all(uid,uid),desc=rows.length?rows.map(r=>`**${r.kind}** — ${money(r.amount)} · <t:${Math.floor(r.created_at/1000)}:R>`).join("\n"):"لا توجد معاملات.";
   return i.reply({embeds:[embed("آخر المعاملات",desc)],ephemeral:true});
  }
  if(i.commandName==="bankadmin"){
   if(!adminAllowed(i))return fail(i,"هذا الأمر مخصص لإدارة السيرفر.");
   const sub=i.options.getSubcommand(),u=i.options.getUser("member");ensure(u.id);
   if(["ban","unban"].includes(sub)){db.setBanned(u.id,sub==="ban");return i.reply({embeds:[embed("تحديث الحساب",`${sub==="ban"?"تم حظر":"تم رفع الحظر عن"} ${u}.`)]});}
   const n=i.options.getInteger("amount");
   if(sub==="set")db.setBalanceTx(u.id,n);else db.adminAdjustTx(u.id,n,sub);
   return i.reply({embeds:[embed("أمر إداري",`العضو: ${u}\nالعملية: ${sub}\nالمبلغ: ${money(n)}`)]});
  }
 }catch(e){
  console.error(e);
  const msg=errors[e.message]||"حدث خطأ غير متوقع. تحقق من الرصيد وحاول مجدداً.";
  if(i.replied||i.deferred)return i.followUp({embeds:[embed("خطأ",msg,0xe74c3c)],ephemeral:true}).catch(()=>{});
  return fail(i,msg).catch(()=>{});
 }
});
client.login(config.token);
