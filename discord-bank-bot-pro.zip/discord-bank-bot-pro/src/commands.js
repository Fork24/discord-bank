const { SlashCommandBuilder } = require("discord.js");
const commands = [
 new SlashCommandBuilder().setName("balance").setDescription("عرض رصيدك أو رصيد عضو").addUserOption(o=>o.setName("member").setDescription("العضو").setRequired(false)),
 new SlashCommandBuilder().setName("daily").setDescription("استلام المكافأة اليومية"),
 new SlashCommandBuilder().setName("work").setDescription("اعمل لتحصل على راتب"),
 new SlashCommandBuilder().setName("deposit").setDescription("إيداع من المحفظة إلى البنك").addIntegerOption(o=>o.setName("amount").setDescription("المبلغ").setMinValue(1).setRequired(true)),
 new SlashCommandBuilder().setName("withdraw").setDescription("سحب من البنك إلى المحفظة").addIntegerOption(o=>o.setName("amount").setDescription("المبلغ").setMinValue(1).setRequired(true)),
 new SlashCommandBuilder().setName("transfer").setDescription("تحويل أموال").addUserOption(o=>o.setName("member").setDescription("المستلم").setRequired(true)).addIntegerOption(o=>o.setName("amount").setDescription("المبلغ").setMinValue(1).setRequired(true)),
 new SlashCommandBuilder().setName("interest").setDescription("استلام فائدة البنك اليومية"),
 new SlashCommandBuilder().setName("loan").setDescription("القروض")
  .addSubcommand(s=>s.setName("take").setDescription("طلب قرض حتى 5 ملايين").addIntegerOption(o=>o.setName("amount").setDescription("مبلغ القرض").setMinValue(10000).setMaxValue(5000000).setRequired(true)))
  .addSubcommand(s=>s.setName("repay").setDescription("سداد القرض").addIntegerOption(o=>o.setName("amount").setDescription("مبلغ السداد").setMinValue(1).setRequired(true)))
  .addSubcommand(s=>s.setName("status").setDescription("عرض حالة القرض")),
 new SlashCommandBuilder().setName("property").setDescription("إدارة العقارات")
  .addSubcommand(s=>s.setName("shop").setDescription("عرض العقارات المتاحة"))
  .addSubcommand(s=>s.setName("buy").setDescription("شراء عقار").addStringOption(o=>o.setName("name").setDescription("العقار").setRequired(true).addChoices({name:"شقة استثمارية",value:"flat"},{name:"فيلا",value:"villa"},{name:"برج تجاري",value:"tower"})))
  .addSubcommand(s=>s.setName("collect").setDescription("تحصيل دخل عقاراتك").addStringOption(o=>o.setName("name").setDescription("العقار").setRequired(true).addChoices({name:"شقة استثمارية",value:"flat"},{name:"فيلا",value:"villa"},{name:"برج تجاري",value:"tower"})))
  .addSubcommand(s=>s.setName("mine").setDescription("عرض عقاراتك"))
  .addSubcommand(s=>s.setName("sell").setDescription("بيع عقار").addStringOption(o=>o.setName("name").setDescription("العقار").setRequired(true).addChoices({name:"شقة استثمارية",value:"flat"},{name:"فيلا",value:"villa"},{name:"برج تجاري",value:"tower"}))),
 new SlashCommandBuilder().setName("leaderboard").setDescription("أغنى 10 أعضاء"),
 new SlashCommandBuilder().setName("history").setDescription("آخر 10 معاملات لك"),
 new SlashCommandBuilder().setName("bankadmin").setDescription("أوامر إدارة البنك")
  .addSubcommand(s=>s.setName("add").setDescription("إضافة أموال").addUserOption(o=>o.setName("member").setDescription("العضو").setRequired(true)).addIntegerOption(o=>o.setName("amount").setDescription("المبلغ").setMinValue(1).setRequired(true)))
  .addSubcommand(s=>s.setName("remove").setDescription("خصم أموال").addUserOption(o=>o.setName("member").setDescription("العضو").setRequired(true)).addIntegerOption(o=>o.setName("amount").setDescription("المبلغ").setMinValue(1).setRequired(true)))
  .addSubcommand(s=>s.setName("set").setDescription("تعيين رصيد").addUserOption(o=>o.setName("member").setDescription("العضو").setRequired(true)).addIntegerOption(o=>o.setName("amount").setDescription("الرصيد").setMinValue(0).setRequired(true)))
  .addSubcommand(s=>s.setName("ban").setDescription("حظر حساب").addUserOption(o=>o.setName("member").setDescription("العضو").setRequired(true)))
  .addSubcommand(s=>s.setName("unban").setDescription("رفع الحظر").addUserOption(o=>o.setName("member").setDescription("العضو").setRequired(true)))
].map(c=>c.toJSON());
module.exports=commands;
