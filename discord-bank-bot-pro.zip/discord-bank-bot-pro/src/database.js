const Database = require("better-sqlite3");
const path = require("node:path");
const fs = require("node:fs");
const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "bank.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS accounts (
 user_id TEXT PRIMARY KEY, wallet INTEGER NOT NULL DEFAULT 0 CHECK(wallet >= 0),
 bank INTEGER NOT NULL DEFAULT 0 CHECK(bank >= 0), last_daily INTEGER NOT NULL DEFAULT 0,
 last_work INTEGER NOT NULL DEFAULT 0, last_interest INTEGER NOT NULL DEFAULT 0,
 loan_balance INTEGER NOT NULL DEFAULT 0 CHECK(loan_balance >= 0),
 loan_due INTEGER NOT NULL DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, from_id TEXT, to_id TEXT,
 amount INTEGER NOT NULL CHECK(amount > 0), kind TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS properties (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
 property_key TEXT NOT NULL, last_collect INTEGER NOT NULL,
 FOREIGN KEY(user_id) REFERENCES accounts(user_id)
);
CREATE INDEX IF NOT EXISTS idx_transactions_from ON transactions(from_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_to ON transactions(to_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_properties_user ON properties(user_id);
`);

// Safe, additive migration for databases created by v1.
const cols = db.prepare("PRAGMA table_info(accounts)").all().map(c => c.name);
for (const [name, sql] of [
 ["last_work", "ALTER TABLE accounts ADD COLUMN last_work INTEGER NOT NULL DEFAULT 0"],
 ["last_interest", "ALTER TABLE accounts ADD COLUMN last_interest INTEGER NOT NULL DEFAULT 0"],
 ["loan_balance", "ALTER TABLE accounts ADD COLUMN loan_balance INTEGER NOT NULL DEFAULT 0"],
 ["loan_due", "ALTER TABLE accounts ADD COLUMN loan_due INTEGER NOT NULL DEFAULT 0"]
]) if (!cols.includes(name)) db.exec(sql);

const getStmt = db.prepare("SELECT * FROM accounts WHERE user_id = ?");
const ensureAccount = (id, start) => {
 db.prepare("INSERT OR IGNORE INTO accounts(user_id,wallet,created_at) VALUES(?,?,?)").run(id,start,Date.now());
 return getStmt.get(id);
};
const log = db.prepare("INSERT INTO transactions(from_id,to_id,amount,kind,created_at) VALUES(?,?,?,?,?)");
const depositTx = db.transaction((id,n) => {
 const a=getStmt.get(id); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 if(a.wallet<n) throw Error("NOT_ENOUGH_WALLET");
 db.prepare("UPDATE accounts SET wallet=wallet-?,bank=bank+? WHERE user_id=?").run(n,n,id);
 log.run(id,id,n,"deposit",Date.now());
});
const withdrawTx = db.transaction((id,n) => {
 const a=getStmt.get(id); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 if(a.bank<n) throw Error("NOT_ENOUGH_BANK");
 db.prepare("UPDATE accounts SET bank=bank-?,wallet=wallet+? WHERE user_id=?").run(n,n,id);
 log.run(id,id,n,"withdraw",Date.now());
});
const transferTx = db.transaction((from,to,n) => {
 const a=getStmt.get(from), b=getStmt.get(to);
 if(!a || !b || a.banned || b.banned) throw Error("ACCOUNT_UNAVAILABLE");
 if(a.wallet<n) throw Error("NOT_ENOUGH_WALLET");
 db.prepare("UPDATE accounts SET wallet=wallet-? WHERE user_id=?").run(n,from);
 db.prepare("UPDATE accounts SET wallet=wallet+? WHERE user_id=?").run(n,to);
 log.run(from,to,n,"transfer",Date.now());
});
const dailyTx = db.transaction((id,reward,cooldown) => {
 const a=getStmt.get(id), now=Date.now(); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 const left=a.last_daily+cooldown-now; if(left>0) return {claimed:false,remaining:left};
 db.prepare("UPDATE accounts SET wallet=wallet+?,last_daily=? WHERE user_id=?").run(reward,now,id);
 log.run(null,id,reward,"daily",now); return {claimed:true};
});
const workTx = db.transaction((id,min,max,cooldown) => {
 const a=getStmt.get(id), now=Date.now(); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 const left=a.last_work+cooldown-now; if(left>0) return {worked:false,remaining:left};
 const amount=Math.floor(Math.random()*(max-min+1))+min;
 db.prepare("UPDATE accounts SET wallet=wallet+?,last_work=? WHERE user_id=?").run(amount,now,id);
 log.run(null,id,amount,"work",now); return {worked:true,amount};
});
const interestTx = db.transaction((id,rate,cap,cooldown) => {
 const a=getStmt.get(id), now=Date.now(); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 const left=a.last_interest+cooldown-now; if(left>0) return {paid:false,remaining:left};
 const amount=Math.min(cap,Math.floor(a.bank*rate));
 db.prepare("UPDATE accounts SET bank=bank+?,last_interest=? WHERE user_id=?").run(amount,now,id);
 if(amount>0) log.run(null,id,amount,"interest",now);
 return {paid:true,amount};
});
const adminAdjustTx = db.transaction((id,n,action) => {
 const a=getStmt.get(id); if(!a) throw Error("ACCOUNT_UNAVAILABLE");
 if(action==="add") db.prepare("UPDATE accounts SET wallet=wallet+? WHERE user_id=?").run(n,id);
 else { if(a.wallet<n) throw Error("NOT_ENOUGH_WALLET"); db.prepare("UPDATE accounts SET wallet=wallet-? WHERE user_id=?").run(n,id); }
 log.run(action==="remove"?id:null,action==="add"?id:null,n,`admin_${action}`,Date.now());
});
const setBalanceTx = db.transaction((id,n) => {
 const a=getStmt.get(id); if(!a) throw Error("ACCOUNT_UNAVAILABLE");
 const diff=Math.abs(n-a.wallet); db.prepare("UPDATE accounts SET wallet=? WHERE user_id=?").run(n,id);
 if(diff>0) log.run(null,id,diff,"admin_set",Date.now());
});
const buyPropertyTx = db.transaction((id,key,cost) => {
 const a=getStmt.get(id); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 if(db.prepare("SELECT 1 FROM properties WHERE user_id=? AND property_key=?").get(id,key)) throw Error("PROPERTY_OWNED");
 if(a.wallet<cost) throw Error("NOT_ENOUGH_WALLET");
 db.prepare("UPDATE accounts SET wallet=wallet-? WHERE user_id=?").run(cost,id);
 db.prepare("INSERT INTO properties(user_id,property_key,last_collect) VALUES(?,?,?)").run(id,key,Date.now());
 log.run(id,null,cost,`property_buy_${key}`,Date.now());
});
const collectPropertyTx = db.transaction((id,key,incomePerMinute,capMs) => {
 const p=db.prepare("SELECT * FROM properties WHERE user_id=? AND property_key=?").get(id,key);
 if(!p) throw Error("NO_PROPERTY");
 const now=Date.now(), elapsed=Math.min(now-p.last_collect,capMs);
 const amount=Math.floor(elapsed/60000*incomePerMinute);
 if(amount<=0) return {amount:0,minutes:Math.floor(elapsed/60000)};
 db.prepare("UPDATE properties SET last_collect=? WHERE id=?").run(now,p.id);
 db.prepare("UPDATE accounts SET wallet=wallet+? WHERE user_id=?").run(amount,id);
 log.run(null,id,amount,`property_income_${key}`,now);
 return {amount,minutes:Math.floor(elapsed/60000)};
});
const sellPropertyTx = db.transaction((id,key,resale) => {
 const p=db.prepare("SELECT id FROM properties WHERE user_id=? AND property_key=?").get(id,key);
 if(!p) throw Error("NO_PROPERTY");
 db.prepare("DELETE FROM properties WHERE id=?").run(p.id);
 db.prepare("UPDATE accounts SET wallet=wallet+? WHERE user_id=?").run(resale,id);
 log.run(null,id,resale,`property_sell_${key}`,Date.now());
});
const takeLoanTx = db.transaction((id,amount) => {
 const a=getStmt.get(id); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 if(a.loan_balance>0) throw Error("LOAN_EXISTS");
 if(amount>5000000) throw Error("LOAN_LIMIT");
 const fee=Math.ceil(amount*0.10), total=amount+fee, due=Date.now()+7*86400000;
 db.prepare("UPDATE accounts SET wallet=wallet+?,loan_balance=?,loan_due=? WHERE user_id=?").run(amount,total,due,id);
 log.run(null,id,amount,"loan",Date.now());
 return {amount,total,due};
});
const repayLoanTx = db.transaction((id,amount) => {
 const a=getStmt.get(id); if(!a || a.banned) throw Error("ACCOUNT_UNAVAILABLE");
 if(a.loan_balance<=0) throw Error("NO_LOAN");
 const pay=Math.min(amount,a.loan_balance);
 if(a.wallet<pay) throw Error("NOT_ENOUGH_WALLET");
 db.prepare("UPDATE accounts SET wallet=wallet-?,loan_balance=loan_balance-?,loan_due=CASE WHEN loan_balance-?=0 THEN 0 ELSE loan_due END WHERE user_id=?").run(pay,pay,pay,id);
 log.run(id,null,pay,"loan_repay",Date.now()); return {paid:pay,left:a.loan_balance-pay};
});

module.exports = {
 db, ensureAccount, getAccount:id=>getStmt.get(id), depositTx, withdrawTx, transferTx, dailyTx, workTx, interestTx,
 adminAdjustTx,setBalanceTx,buyPropertyTx,collectPropertyTx,sellPropertyTx,takeLoanTx,repayLoanTx,
 setBanned:(id,v)=>db.prepare("UPDATE accounts SET banned=? WHERE user_id=?").run(v?1:0,id),
 leaderboard:db.prepare("SELECT user_id,wallet,bank,(wallet+bank) total FROM accounts WHERE banned=0 ORDER BY total DESC LIMIT 10"),
 history:db.prepare("SELECT * FROM transactions WHERE from_id=? OR to_id=? ORDER BY id DESC LIMIT 10"),
 properties:id=>db.prepare("SELECT property_key FROM properties WHERE user_id=? ORDER BY id").all(id)
};
