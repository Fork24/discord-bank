const { REST, Routes } = require("discord.js");
const config=require("./config"), commands=require("./commands");
(async()=>{const rest=new REST({version:"10"}).setToken(config.token);
 await rest.put(Routes.applicationGuildCommands(config.clientId,config.guildId),{body:commands});
 console.log(`تم تسجيل ${commands.length} أمر بنجاح.`);})().catch(e=>{console.error(e);process.exit(1);});
